Strategic Buying Agents Slides - copy package

Open index.html to view the slides.

If animations do not load from a double-clicked file, serve this folder with a
small static server and open:

  http://127.0.0.1:8765/index.html

Example PowerShell command from this folder:

  py -m http.server 8765

Included files:

- index.html
- images/
- assets/
- vendor/
